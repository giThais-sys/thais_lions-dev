let usuarios =[{
    nome: 'flavia',
    email:'flavia@gmail.com',
    telefone: '346463-643436'
}]

   [{ nome: 'bruno',
    email: 'bruno@hotmail.com',
    telefone: '43552-64366'
}]

module.exports= usuarios