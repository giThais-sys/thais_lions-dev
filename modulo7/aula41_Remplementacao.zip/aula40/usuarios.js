module.exports =[{
    id:2,
    nome: 'flavia',
    email:'flavia@gmail.com',
    telefone: '346463-643436'
},

   {id:4,
    nome: 'bruno',
    email: 'bruno@hotmail.com',
    telefone: '43552-64366'
}]

