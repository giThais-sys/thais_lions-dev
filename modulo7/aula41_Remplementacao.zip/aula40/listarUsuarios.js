let usuarios = require ('./usuarios')
function listarUsuarios() {
 usuarios.forEach(usuario=> {
 console.log(`id:${usuario.id} nome: ${usuario.nome}, email: ${usuario.email}, telefone: ${usuario.telefone}`)
   });
   
}
module.exports= listarUsuarios
