
function removerUsuarios(index) {
usuarios.splice(index, 1) 
index= parseInt(prompt('digite o usuario a ser deletado:'))-1
removerUsuario(index)
console.log('usuario deletado com sucesso!')


}
module.exports= removerUsuarios













