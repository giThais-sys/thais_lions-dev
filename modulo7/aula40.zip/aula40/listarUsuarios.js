
function listarUsuarios(usuarios) {
 usuarios.forEach((usuario, index)=> {
 console.log(`${index+1} nome: ${usuario.nome}, rua: ${usuario.email}, telefone: ${usuario.telefone}`)
   });
   
}
module.exports= listarUsuarios
