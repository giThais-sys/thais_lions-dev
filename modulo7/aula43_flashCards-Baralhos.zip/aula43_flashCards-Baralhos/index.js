let baralhos= [
    {titulo: 'adivinhe a cor', id: 1},
    {titulo: 'geometria' , id: 2}
]
let flashcards=[ 

{id: 1, pergunta: 'qual é a cor da maçã?', resposta: 'depende da estacao 🤡', idBaralho: 1},
{id: 2, pergunta: 'quantos lados tem um quadrilátero?', resposta: 'um quadrilátero tem quatro lados, pois quadri é igual a quatro e látero é igual a lados', idBaralho:2}

]
module.exports = {baralhos,flashcards}