let usuarios= require ('./usuarios')

function adicionarUsuarios(usuario) {
   usuario.id= usuarios.length +1;

   }


module.exports= adicionarUsuarios
