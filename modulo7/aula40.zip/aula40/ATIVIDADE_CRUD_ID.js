const prompt= require ('prompt-sync') ()
const adicionarUsuarios= require ('./adicionarUsuarios')
const usuarios= require ('./usuarios')
const listarUsuarios= require ('./listarUsuarios')
const editarUsuarios= require ('./editarUsuarios')
const removerUsuarios= require ('./removerUsuarios')


exibirMenu()

function exibirMenu() {
  console.log(`
  Menu:
  1. adicionar usuario
  2. listar usuario
  3. editar usuario
  4. remover usuario
  5. sair
  `)
}
const opcao= prompt ('digite a sua opcao:') 

let index
  switch (opcao) {
   case '1':
    adicionarUsuarios(usuarios)
    exibirMenu()
    break

   case '2':
    listarUsuarios(usuarios) 
    exibirMenu()
    break

   case '3':
    editarUsuarios(usuarios)
    exibirMenu()
    break
    
   case '4':
    removerUsuarios(usuarios)
    exibirMenu()
    break    

   case '5': 
    console.log('encerrando o programa')
    break

   default:
    console.log('usuario invalido')
    exibirMenu()

}
 