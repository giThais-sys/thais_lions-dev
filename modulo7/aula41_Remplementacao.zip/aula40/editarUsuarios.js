function editarUsuarios(index, usuarios, novoUsuario) {
usuarios[index]= novoUsuario

console.log('usuario editado com sucesso!')

}
module.exports= editarUsuarios



















