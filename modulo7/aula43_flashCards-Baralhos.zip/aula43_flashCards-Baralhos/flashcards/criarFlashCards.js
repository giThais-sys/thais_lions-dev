let {flashcards}= require ('../app.js')
function criarFlashCard(){
flashcards.id = flashcards.length +1
criarFlashCard= ({id, pergunta, resposta, idBaralho})
flashcards.push(flashcard)
console.log ('flashCard criado com sucesso!')
            
}
module.exports= criarFlashCard
            
        