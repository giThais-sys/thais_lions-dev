function editarUsuarios(index, novoUsuario) {
usuarios[index]= novoUsuario
index= parseInt(prompt('digite o novo usuario a ser cadastrado:'))-1
const novoNome = prompt ('digite o novo nome a ser cadastrado:')
const novoEmail= prompt ('digite a novo email a ser cadastrado:')
const novoTelefone= prompt ('digite o novo telefone a ser cadastrado:')
console.log('usuario editado com sucesso!')

}
module.exports= editarUsuarios



















